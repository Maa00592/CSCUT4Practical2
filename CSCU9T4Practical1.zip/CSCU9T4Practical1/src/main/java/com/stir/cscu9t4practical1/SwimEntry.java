package com.stir.cscu9t4practical1;

   public class SwimEntry extends Entry {


   private String pool;


   public SwimEntry (String n, int d, int m, int y, int h, int min, int s, float dist, String po) {

   super( n, d, m, y, h, min, s, dist); 
   this.pool=po;
}

   public String getpool() {
	
	return pool;	
}
   public void setpool(String po) {
this.pool= po;
}

	 public String getEntry () {
		   String result = getName()+" ran " + getDistance() + " km in "
		             +getHour()+":"+getMin()+":"+ getSec() + " on "
		             +getDay()+"/"+getMonth()+"/"+getYear()+"\n"+getpool()+ ":";
		   return result;
		  } 
	

}
