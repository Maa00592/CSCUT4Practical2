package com.stir.cscu9t4practical1;

public class CycleEntry extends Entry {
	
	private String terrain;
	private String tempo;
	
	
	public CycleEntry (String n, int d, int m, int y, int h, int min, int s, float dist, String te, String tm) {

	super( n, d, m, y, h, min, s, dist); 
	this.terrain=te;
	this.tempo=tm;
	}
	
	public String getterrain() {
		
		return terrain;
		} //getterrain
    public void setterrain(String te) {
		this.tempo= te; 
        } //setterrain 

    public String gettempo () {
    	 return tempo;
    } //gettempo
    public void settempo(String tm) {
    	this.tempo= tm;
    	
    } //settempo
  
    
    public String getEntry () {
			   String result = getName()+" ran " + getDistance() + " km in "
			             +getHour()+":"+getMin()+":"+ getSec() + " on "
			             +getDay()+"/"+getMonth()+"/"+getYear()+"\n"+getterrain()+":"+gettempo()+":";
			   return result;
			  } 
		
	
}
